/**
 * Created by duy on 11/26/15.
 */
public class FieldAndStones {

    public static void main(String[] args) {

    }

    public static void driver() {

    }

    public class Coordinate {

        private int x;
        private int y;

        public Coordinate(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public int getY() {
            return y;
        }

        public void setY(int y) {
            this.y = y;
        }

        public int getX() {
            return x;
        }

        public void setX(int x) {
            this.x = x;
        }


    }

}
